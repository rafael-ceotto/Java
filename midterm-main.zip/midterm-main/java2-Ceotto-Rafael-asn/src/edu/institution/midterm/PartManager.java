package edu.institution.midterm;

import java.util.List;

public interface PartManager {

	public int importPartStore(String filePath); 
	
	public Part costPart(String partNumber);
	
	public Part retrievePart(String partNumber);
	
	public List<Part> getFinalAssemblies();
	
	public List<Part> getPurchasePartsByPrice();
}
