package edu.institution.midterm;

import java.util.List;

public class Part {

	public static final String TYPE_ASSEMBLY = "ASSEMBLY";
	public static final String TYPE_COMPONENTS = "COMPONENTS";
	public static final String TYPE_PURCHASE = "PURCHASE";
	private String partNumber;//identifies this part in the part store
	private String name; //the display name for this part
	private String partType;
	
	// "ASSEMBLY" parts are the final assemblies that are sold to the customers.
	// "COMPONENT" parts are the sub component parts that make up the final assemblies.
	// "PURCHASE" parts are the external components purchased from a vendor.
	
	private float price; //the price of this part.
	private List<BomEntry> billOfMaterial; //the list of BOM entries one level under this part.
	
	public String getPartNumber() {
		return partNumber;
	}
	
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPartType() {
		return partType;
	}
	
	public void setPartType(String partType) {
		this.partType = partType;
	}
	
	public float getPrice() {
		return price;
	}
	
	public void setPrice(float price) {
		this.price = price;
	}
	
	public List<BomEntry> getBillOfMaterial() {
		return billOfMaterial;
	}
	
	public void setBillOfMaterial(List<BomEntry> billOfMaterial) {
		this.billOfMaterial = billOfMaterial;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((billOfMaterial == null) ? 0 : billOfMaterial.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((partNumber == null) ? 0 : partNumber.hashCode());
		result = prime * result + ((partType == null) ? 0 : partType.hashCode());
		result = prime * result + Float.floatToIntBits(price);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Part other = (Part) obj;
		if (billOfMaterial == null) {
			if (other.billOfMaterial != null)
				return false;
		} else if (!billOfMaterial.equals(other.billOfMaterial))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (partNumber == null) {
			if (other.partNumber != null)
				return false;
		} else if (!partNumber.equals(other.partNumber))
			return false;
		if (partType == null) {
			if (other.partType != null)
				return false;
		} else if (!partType.equals(other.partType))
			return false;
		if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Part [partNumber = " + partNumber + ", name = " + name + ", partType = " + partType + ", price = " + price
				+ ", billOfMaterial = " + billOfMaterial + "]";
	}	
}
