package edu.institution.midterm;

import java.io.File;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import com.google.gson.Gson;

public class PartManagerImpl implements PartManager{

	File file = null;
	
	public static void main(String[] args) {
		(new PartManagerImpl()).
		importPartStore("/bom.json/bom.json");
	}
	
	public int importPartStore(String filePath) {
		
		try {		    
		    Gson gson = new Gson();
		    Reader reader = Files.newBufferedReader(Paths.get(filePath));
			Part[] parts = gson.fromJson(reader, Part[].class);	
		    reader.close();
		    for(Part part: parts) {
		    	System.out.println(part.getName());
		    }
		} catch (Exception ex) {
		    ex.printStackTrace();
		}		
		return 0;
	}
	
	public List<Part> getFinalAssemblies(){
				 
		/*Scan all parts imported in the part store and return only the final assembly parts. Final assembly parts have a
		  part type of �ASSEMBLY�. The returned list of final assembly parts should be sorted in ascending order by
          their part number.
        */		
		return null;
	}
	
	public List<Part> getPurchasePartsByPrice() {
		
		/*Scan all parts imported in the part store and return only the purchased parts. Purchased parts have a part
		  type of �PURCHASE�. The returned list of purchased parts should be sorted in descending order by their price
	 	  (highest price to lowest price).
	 	*/		
		return null;
	}
	
	public Part retrievePart(String partNumber) {
		 
		/*Return the Part instance from the part store that is related to the supplied part number. Return null if no
		  Part instance is found for the supplied part number.
		*/
		return null;
	}
	
	public Part costPart(String partNumber) {
		
		/*This method computes the cost of manufacturing the part associated with the supplied part number. Along
		  with computing the manufacturing cost of the supplied part, this method also computes the cost of each sub
		  component part, and their sub component parts, until all parts under the supplied part have been costed.
		*/		
		return null;
	}		
			
}
