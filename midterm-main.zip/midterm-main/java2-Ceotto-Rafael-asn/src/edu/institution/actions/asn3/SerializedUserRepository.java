//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021

package edu.institution.actions.asn3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import edu.institution.UserRepository;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class SerializedUserRepository implements UserRepository {

	private String filePath;
	private String fileName;
	private List<LinkedInUser> users;
	private File file;

	@Override
	public void init(String filePath, String fileName) {

		this.filePath = filePath;
		this.fileName = fileName;
		this.file = new File(this.filePath + File.separator + this.fileName);
		this.checkFile();
		this.users = this.retrieveAll();
	}

	@Override
	public void add(LinkedInUser user) throws LinkedInException {
		try {
			if (user.getUsername().equals("")) {
				throw new LinkedInException("The user name and type are required to add a new user.");
			}
			if (user.getType().equals("")) {
				throw new LinkedInException("Invalid user type. Valid types are P or S.");
			}			
			if(!(user.getType().equals("P") || user.getType().equals("S"))) {
				try {
					throw new LinkedInException("Invalid user type. Valid types are P or S.");
				} catch (LinkedInException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
						
			} else {
				users.add(user);
				this.saveAll();
			}
					
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void saveAll() {

		try {
			FileOutputStream fout = new FileOutputStream(this.file);
			ObjectOutputStream oos = new ObjectOutputStream(fout);
			oos.writeObject(this.users);
			oos.close();
			fout.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void delete(LinkedInUser user) {
		if (!users.contains(user)) {
			try {
				throw new LinkedInException("User not located");
			} catch (LinkedInException e) {
				e.printStackTrace();
			}
		}

		if (users.contains(user)) {
			users.remove(user);
		}

		this.saveAll();

	}

	@Override
	public LinkedInUser retrieve(String username) {
		for (LinkedInUser user : this.users) {
			if (user.getUsername().equals(username)) {
				return user;
			}
		}
		return null;
	}

	@Override
	public List<LinkedInUser> retrieveAll() {
		return this.users != null ? this.users : new ArrayList<LinkedInUser>();
	}
	
	private boolean checkFile() {

		FileInputStream fis;
		ObjectInputStream ois;
		try {
			if (this.file.exists()) {
				fis = new FileInputStream(this.file);
				ois = new ObjectInputStream(fis);
				this.users = (ArrayList<LinkedInUser>) ois.readObject();
				ois.close();
				fis.close();
			} else {
				this.file.createNewFile();
				this.users = new ArrayList<LinkedInUser>();
			}
			for (LinkedInUser u : this.users) {
				System.out.println(u.toString());
			}
			
			return true;
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return false;
		} catch (ClassNotFoundException c) {
			c.printStackTrace();
			return false;
		}
	}
}
