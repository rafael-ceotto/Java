package edu.institution.actions.asn4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class DegreeOfSeparationAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {

		ApplicationHelper.showMessage("Type the user name to show the degree of separation");
		String name = scanner.nextLine();

		try {
			LinkedInUser connection = userRepository.retrieve(name);
			if (connection != null) {
				List<LinkedInUser> connectionList = new ArrayList<LinkedInUser>();
				getDegreesOfSeparation(loggedInUser, connection, connectionList);

				if (connectionList.size() == 1 && connectionList.get(0).getUsername() == loggedInUser.getUsername()) {
					System.out.print(
							loggedInUser.getUsername() + "->" + connection.getUsername());
					System.out.println("\n" + loggedInUser.getUsername() + " is 0 degrees separated of " + connection.getUsername());
				} else if (connectionList.size() > 0) {
					System.out.print(loggedInUser.getUsername());
					for (int i = connectionList.size(); i > 0; i--) {
						System.out.print("->" + connectionList.get(i - 1).getUsername());
					}
					System.out.print("->" + connection.getUsername());
					System.out.println("\n" + loggedInUser.getUsername() + " is " + (connectionList.size())
							+ " degrees separated of " + connection.getUsername());
				} else {
					System.out.println("There is no connections linked to " + connection.getUsername());
					return true;
				}

			} else {
				System.out.println("There is connections linked to " + name);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			System.exit(0);
		}

		return true;
	}

	public void getDegreesOfSeparation(LinkedInUser userSource, LinkedInUser userDestination, List<LinkedInUser> way) {
		if (userSource.getUsername().equalsIgnoreCase(userDestination.getUsername())) {
			return;
		}

		if (userSource.getConnections().contains(userDestination) && !way.contains(userSource)) {
			way.add(userSource);
			return;
		}

		for (LinkedInUser userSourceConnection : userSource.getConnections()) {
			getDegreesOfSeparation(userSourceConnection, userDestination, way);
			if (way.size() > 0 && !way.contains(userSourceConnection)) {
				way.add(userSourceConnection);
				return;
			}
		}

		return;
	}
}
