package edu.institution.actions.asn4;

import java.util.Scanner;

import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class AddConnectionAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
				
		ApplicationHelper.showMessage("Type the user name to connect with");
		String name = scanner.nextLine();

		LinkedInUser connection = userRepository.retrieve(name);
		try {
			if (connection != null) {
				for(LinkedInUser user: loggedInUser.getConnections()) {
					
					if(user.getUsername().equalsIgnoreCase(connection.getUsername())) {
						loggedInUser.addConnection(connection);
					}					
				}
				loggedInUser.addConnection(connection);
				System.out.println("The connection was added successfully");				
			} else {
				System.out.println("There is no user with that user name");
			}
		} catch (LinkedInException e) {
			System.out.println(e.getMessage());
		}
		return true;

	}
}
