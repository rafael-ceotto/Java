package edu.institution.actions.asn6;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;


public class ListUserAlphabeticallyAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		
		List<LinkedInUser> list = userRepository.retrieveAll();
		LinkedInUserComparatorAlphabetically comparingListName = new LinkedInUserComparatorAlphabetically();
		Collections.sort(list, comparingListName);
		for (LinkedInUser v : list) {
			System.out.println(v.getUsername());
		}
		
		return true;
	
	}
}
