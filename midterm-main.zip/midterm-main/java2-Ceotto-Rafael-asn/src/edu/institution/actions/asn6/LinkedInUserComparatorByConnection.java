package edu.institution.actions.asn6;

import java.util.Comparator;

import edu.institution.asn2.LinkedInUser;

public class LinkedInUserComparatorByConnection implements Comparator<LinkedInUser> {

	@Override
	public int compare(LinkedInUser userC1, LinkedInUser userC2) {		
		
		return userC2.getConnections().size() - userC1.getConnections().size();
	}

}
