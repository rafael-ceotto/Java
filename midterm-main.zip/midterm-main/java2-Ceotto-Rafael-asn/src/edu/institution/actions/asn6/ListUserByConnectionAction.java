package edu.institution.actions.asn6;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class ListUserByConnectionAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		
		List<LinkedInUser> list = userRepository.retrieveAll();
		LinkedInUserComparatorByConnection comparingListName = new LinkedInUserComparatorByConnection();
		Collections.sort(list, comparingListName);
		for (LinkedInUser v : list) {
			System.out.println(v.getUsername() + " ; connection size = " + v.getConnections().size());
		}
		
		return true;
	}

}
