package edu.institution.actions.asn6;

import java.util.Comparator;

import edu.institution.asn2.LinkedInUser;

public class LinkedInUserComparatorAlphabetically implements Comparator<LinkedInUser> {

	@Override
	public int compare(LinkedInUser userA1, LinkedInUser userA2) {
		
		return userA1.getUsername().compareToIgnoreCase(userA2.getUsername());
	}

}
