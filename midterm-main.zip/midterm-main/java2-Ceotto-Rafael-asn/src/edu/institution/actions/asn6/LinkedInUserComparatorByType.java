package edu.institution.actions.asn6;

import java.util.Comparator;

import edu.institution.asn2.LinkedInUser;

public class LinkedInUserComparatorByType implements Comparator<LinkedInUser>{

	@Override
	public int compare(LinkedInUser userT1, LinkedInUser userT2) {
		
		String userY = userT1.getType() + userT1.getUsername();
		String userU = userT2.getType() + userT2.getUsername();
		
		return userY.compareToIgnoreCase(userU);
		
	}

}
