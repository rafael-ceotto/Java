//Rafael Ceotto
//CIS2217
//Assignment 5 - Utilities Class
//2021

package edu.institution.actions.asn5;

import java.util.ArrayList;
import java.util.List;


public class Utilities {
	
	public <T> void removeDuplicates(List<T> items){
		
		List<T> distinctList = new ArrayList<>();
		if (items.size() > 0) {
			for (T item : items) {
				boolean exists = false;
				for (T i : distinctList) {
					if (item == i) {
						exists = true;
					}
				}
				if (!exists) {
					distinctList.add(item);
				}
			}
			items.clear();
			items.addAll(distinctList);
		} 	
		
	}
	
	public <E extends Comparable<E>> E linearSearch(List<E> list, E key){
		
		if(list == null || key == null) {
			return null;
		}
				
		for (E item : list) {
			if(item.compareTo(key) > 0) {
				return key;
			}
		}		
		return null;
	}
	
	public String linearSearch(List<String> list, String key){
		
		if(list == null || key == null) {
			return null;
		}
				
		for (String item : list) {
			if(item.equals(key)) {
				return key;
			}
		}		
		return null;
	}
	
	public Integer linearSearch(List<Integer> list, Integer key){
		
		if(list == null || key == null) {
			return null;
		}
				
		for (Integer item : list) {
			if(item.equals(key)) {
				return key;
			}
		}		
		return null;
	}
	
	
}
