//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021

package edu.institution.asn2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LinkedInUser extends UserAccount implements Serializable, Comparable<LinkedInUser> {

	private static final long serialVersionUID = -3080292664859634039L;
	private String type;
	private List<LinkedInUser> connections = new ArrayList<>();
	

	public LinkedInUser(String username, String password) {
		super(username, password);
	}

	@Override
	public void setType(String type) {
		this.type = type;

	}

	public String getType() {
		return type;
	}

	public void addConnection(LinkedInUser user) throws LinkedInException {

		if (!connections.contains(user)) {

			connections.add(user);
			//user.addConnection(this);

		}

		else {

			throw new LinkedInException("You are already connected with this user");
		}

	}

	public void removeConnection(LinkedInUser user) throws LinkedInException {

		if (connections.contains(user)) {

			connections.remove(user);
			//user.removeConnection(this);

		}

		else {
			throw new LinkedInException("You are NOT connected with this user");
		}

	}

	public List<LinkedInUser> getConnections() {

		// copy of ArrayList
		return new ArrayList<LinkedInUser>(connections);
	}

	@Override
	public int compareTo(LinkedInUser linkUser) {
		// TODO Auto-generated method stub
		return this.getUsername().compareToIgnoreCase(linkUser.getUsername());
	}

	@Override
	public String toString() {
		return this.getUsername();
	}

}
