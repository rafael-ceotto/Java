//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021


package edu.institution.asn2;

import java.lang.Exception;
import java.lang.Throwable;

public class LinkedInException extends Exception{
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public LinkedInException() {
		super();
	}
	
	
	public LinkedInException(String message) {
		super(message);
	}
	
	
	public LinkedInException(String message, Throwable cause) {
		super(message, cause);
	}
	
	
	protected LinkedInException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	
	
	public LinkedInException(Throwable cause) {
		super(cause);
	}

}
