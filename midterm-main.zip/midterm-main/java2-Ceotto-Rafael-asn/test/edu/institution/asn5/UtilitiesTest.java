//Rafael Ceotto
//CIS2217
//Assignment 5 - UtilitiesTest Class
//2021

package edu.institution.asn5;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import edu.institution.actions.asn5.Utilities;
import edu.institution.asn2.LinkedInUser;

public class UtilitiesTest {

	@Test
	public void removeDuplicatesIntegerTest() {
		
		List<Integer> duplicatedList = new ArrayList<Integer>();
		duplicatedList.add(1);
		duplicatedList.add(2);
		duplicatedList.add(2);
		duplicatedList.add(3);
		duplicatedList.add(3);
		duplicatedList.add(3);
		
		List<Integer> expectedResultList = new ArrayList<Integer>();
		expectedResultList.add(1);
		expectedResultList.add(2);
		expectedResultList.add(3);
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(duplicatedList);
		assertEquals(duplicatedList, expectedResultList);
		
	}
	
	@Test
	public void removeDuplicatesStringTest() {
		
		List<String> duplicatedList = new ArrayList<>();
		duplicatedList.add("one");
		duplicatedList.add("two");
		duplicatedList.add("two");
		duplicatedList.add("three");
		duplicatedList.add("three");
		duplicatedList.add("three");
		
		List<String> expectedResultList = new ArrayList<>();
		expectedResultList.add("one");
		expectedResultList.add("two");
		expectedResultList.add("three");
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(duplicatedList);
		assertEquals(duplicatedList, expectedResultList);
	}
	
	@Test
	public void removeDuplicatesLinkedInUserTest() {
		List<LinkedInUser> duplicatedList = new ArrayList<>();
		LinkedInUser user1 = new LinkedInUser("user1", "123"); 
		duplicatedList.add(user1);
		duplicatedList.add(user1);
		duplicatedList.add(user1);
		
		LinkedInUser user2 = new LinkedInUser("user2", "456"); 
		duplicatedList.add(user2);
		duplicatedList.add(user2);
		duplicatedList.add(user2);		
		
		List<LinkedInUser> expectedResultList = new ArrayList<>();
		expectedResultList.add(user1);
		expectedResultList.add(user2);
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(duplicatedList);
		assertEquals(duplicatedList, expectedResultList);
	}
	
	@Test
	public void linearSearchWithStringListNull() {
		
		Utilities utilities = new Utilities();
		String returnedList = utilities.linearSearch(null, "Any value passed");
		assertNull(returnedList);
	}
	
	@Test
	public void linearSearchWithIntegerListNull() {
		
		Utilities utilities = new Utilities();
		Integer returnedList = utilities.linearSearch(null, 1);
		assertNull(returnedList);
	}
	
	@Test
	public void linearSearchWithLinkedInUserListNull() {
		
		LinkedInUser user1 = new LinkedInUser("user1", "hardcode");
		Utilities utilities = new Utilities();
		LinkedInUser returnedList = utilities.linearSearch(null, user1);
		assertNull(returnedList);
	}
	
	@Test
	public void linearSearchforStringWithKeyNull() {
		
		Utilities utilities = new Utilities();
		String returnedKey = utilities.linearSearch(new ArrayList<String>(), null);
		assertNull(returnedKey);	
			
	}
	
	@Test
	public void linearSearchForIntegerWithKeyNull() {
		
		Utilities utilities = new Utilities();
		Integer returnedKey = utilities.linearSearch(new ArrayList<Integer>(), null);
		assertNull(returnedKey);	
			
	}
	
	@Test
	public void linearSearchForLinkedInUserWithKeyNull() {
		
		Utilities utilities = new Utilities();
		LinkedInUser returnedKey = utilities.linearSearch(new ArrayList<LinkedInUser>(), null);
		assertNull(returnedKey);	
			
	}
	
	@Test
	public void passingValidArrayOfStringsToFindSuppliedValidKey() {
		
		List<String> validList = new ArrayList<>();
		validList.add("one");
		validList.add("two");
		validList.add("three");
		Utilities utilities = new Utilities();
		String returnedKey = utilities.linearSearch(validList, "two");
		assertTrue(returnedKey.equals("two"));

	}
	
	@Test
	public void passingValidArrayOfIntegersToFindSuppliedValidKey() {
		
		List<Integer> validList = new ArrayList<>();
		validList.add(1);
		validList.add(2);
		validList.add(3);
		Utilities utilities = new Utilities();
		Integer returnedKey = utilities.linearSearch(validList, 2);
		assertTrue(returnedKey.equals(2));

	}
	
	@Test
	public void passingValidArrayOfObjectsToFindSuppliedValidKey() {
		
		List<LinkedInUser> validList = new ArrayList<>();
		LinkedInUser user1 = new LinkedInUser("user1", "hardcode");
		validList.add(user1);
		validList.add(new LinkedInUser("user2", "softcode"));
		validList.add(new LinkedInUser("user3", "immutablecode"));
		
		Utilities utilities = new Utilities();
		LinkedInUser returnedKey = utilities.linearSearch(validList, user1);
		assertTrue(returnedKey.equals(user1));

	}
	
	@Test
	public void passingValidStringArrayToFindSuppliedInvalidKey() {
		
		List<String> validList = new ArrayList<>();
		validList.add("one");
		validList.add("two");
		validList.add("three");
		Utilities utilities = new Utilities();
		String returnedKey = utilities.linearSearch(validList, "four");
		assertNull(returnedKey);

	}
	
	@Test
	public void passingValidIntegerArrayToFindSuppliedInvalidKey() {
		
		List<Integer> validList = new ArrayList<>();
		validList.add(1);
		validList.add(2);
		validList.add(3);
		Utilities utilities = new Utilities();
		Integer returnedKey = utilities.linearSearch(validList, 4);
		assertNull(returnedKey);

	}
	
	@Test
	public void passingValidArrayOfObjectsToFindSuppliedInvalidKey() {
		
		List<LinkedInUser> validList = new ArrayList<>();
		LinkedInUser user1 = new LinkedInUser("user1", "hardcode");
		validList.add(user1);
		validList.add(new LinkedInUser("user2", "softcode"));
		validList.add(new LinkedInUser("user3", "immutablecode"));		
		Utilities utilities = new Utilities();
		LinkedInUser returnedKey = utilities.linearSearch(validList, new LinkedInUser("user4", "changeCode"));
		assertNull(returnedKey);		
	}
		
}
