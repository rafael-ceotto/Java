package edu.institution.midterm;

public class MidtermTest {

}
