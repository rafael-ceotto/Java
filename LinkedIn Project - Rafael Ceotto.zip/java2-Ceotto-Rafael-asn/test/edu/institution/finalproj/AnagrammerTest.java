package edu.institution.finalproj;

import java.util.Set;

import org.junit.Test;

public class AnagrammerTest {

	@Test
	public void setTestForFile() {
		AnagramDataReaderImpl a = new AnagramDataReaderImpl();
		Set<String> s = a.readData();
		for (String str : s) {
			System.out.println(str);
		}
	}

	@Test
	public void setAnagramEvaluatorImplForTest() {
		AnagramEvaluatorImpl a = new AnagramEvaluatorImpl();
		String anagram = "reef";
		System.out.println(a.evaluate(anagram, "nf"));
		System.out.println(a.evaluate(anagram, "words"));
	}

}
