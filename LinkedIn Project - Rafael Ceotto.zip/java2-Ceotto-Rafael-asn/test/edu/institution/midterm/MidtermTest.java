package edu.institution.midterm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class MidtermTest {
	
	@Test
	public void verifyAssemblyCostIsCorrectOneOfFourTest(){
		
		Part part = new Part();
		PartManager partManagerTest = new PartManagerImpl();
		partManagerTest.importPartStore("bom.json");
		part = partManagerTest.costPart("290B7266J1");
		assertEquals(part.getPrice(), 415.16f, 0.0);
	}
	
	@Test
	public void verifyAssemblyCostIsCorrectTwoOfFourTest(){
		
		Part part = new Part();
		PartManager partManagerTest = new PartManagerImpl();
		partManagerTest.importPartStore("bom.json");
		part = partManagerTest.costPart("290B7266J2");
		assertEquals(part.getPrice(), 532.20f, 0.0);
	}
	
	@Test
	public void verifyAssemblyCostIsCorrectThreeOfFourTest(){
		
		Part part = new Part();
		PartManager partManagerTest = new PartManagerImpl();
		partManagerTest.importPartStore("bom.json");
		part = partManagerTest.costPart("290B7266J6");
		assertEquals(part.getPrice(), 334.10f, 0.0);
	}
	
	@Test
	public void verifyAssemblyCostIsCorrectFourOfFourTest(){
		
		Part part = new Part();
		PartManager partManagerTest = new PartManagerImpl();
		partManagerTest.importPartStore("bom.json");
		part = partManagerTest.costPart("20-0001");
		assertEquals(part.getPrice(), 96.39f, 0.0);
	}
	
	@Test
	public void verifyComponentsCostIsCorrectTest(){
		
		Part part = new Part();
		PartManager partManagerTest = new PartManagerImpl();
		partManagerTest.importPartStore("bom.json");
		part = partManagerTest.costPart("20-0015");
		assertEquals(part.getPrice(), 70.46f, 0.0);
	}
	
	@Test
	public void verifyAssemblyListTest() {
		
		PartManager partManagerTest = new PartManagerImpl();
		partManagerTest.importPartStore("bom.json");
		List<Part> assemblyPartList = new ArrayList<Part>();
		assemblyPartList.add(partManagerTest.retrievePart("20-0001"));
		assemblyPartList.add(partManagerTest.retrievePart("290B7266J1"));
		assemblyPartList.add(partManagerTest.retrievePart("290B7266J2"));
		assemblyPartList.add(partManagerTest.retrievePart("290B7266J6"));		
		List<Part> setList = partManagerTest.getFinalAssemblies();
		assertEquals(assemblyPartList, setList);
	}
	
	@Test
	public void verifyPurchaseListTest() {
		
		PartManager partManagerTest = new PartManagerImpl();
		partManagerTest.importPartStore("bom.json");
		List<Part> purchasePartList = new ArrayList<Part>();
		purchasePartList.add(partManagerTest.retrievePart("290B381041"));
		purchasePartList.add(partManagerTest.retrievePart("290B3810C3"));
		purchasePartList.add(partManagerTest.retrievePart("290B3810C1"));
		purchasePartList.add(partManagerTest.retrievePart("290B3810A2"));
		purchasePartList.add(partManagerTest.retrievePart("40-0009"));
		purchasePartList.add(partManagerTest.retrievePart("40-0048"));
		purchasePartList.add(partManagerTest.retrievePart("40-0047"));
		purchasePartList.add(partManagerTest.retrievePart("40-0049"));
		purchasePartList.add(partManagerTest.retrievePart("40-0044"));
		purchasePartList.add(partManagerTest.retrievePart("40-0043"));
		purchasePartList.add(partManagerTest.retrievePart("40-0046"));
		purchasePartList.add(partManagerTest.retrievePart("40-0045"));
		purchasePartList.add(partManagerTest.retrievePart("40-0084"));
		purchasePartList.add(partManagerTest.retrievePart("40-0042"));
		purchasePartList.add(partManagerTest.retrievePart("40-0041"));
		purchasePartList.add(partManagerTest.retrievePart("40-0081"));
		purchasePartList.add(partManagerTest.retrievePart("40-0039"));
		purchasePartList.add(partManagerTest.retrievePart("40-0038"));
		purchasePartList.add(partManagerTest.retrievePart("40-0077"));
		purchasePartList.add(partManagerTest.retrievePart("40-0076"));
		purchasePartList.add(partManagerTest.retrievePart("40-0078"));
		purchasePartList.add(partManagerTest.retrievePart("40-0073"));
		purchasePartList.add(partManagerTest.retrievePart("40-0072"));
		purchasePartList.add(partManagerTest.retrievePart("40-0075"));
		purchasePartList.add(partManagerTest.retrievePart("50-0010"));
		purchasePartList.add(partManagerTest.retrievePart("40-0074"));
		purchasePartList.add(partManagerTest.retrievePart("40-0071"));
		purchasePartList.add(partManagerTest.retrievePart("40-0070"));
		purchasePartList.add(partManagerTest.retrievePart("90-0007"));
		purchasePartList.add(partManagerTest.retrievePart("20-0005"));
		purchasePartList.add(partManagerTest.retrievePart("40-0069"));
		purchasePartList.add(partManagerTest.retrievePart("40-0066"));
		purchasePartList.add(partManagerTest.retrievePart("40-0068"));
		purchasePartList.add(partManagerTest.retrievePart("50-0083"));
		purchasePartList.add(partManagerTest.retrievePart("40-0067"));
		purchasePartList.add(partManagerTest.retrievePart("40-0062"));
		purchasePartList.add(partManagerTest.retrievePart("50-0089"));
		purchasePartList.add(partManagerTest.retrievePart("40-0061"));
		purchasePartList.add(partManagerTest.retrievePart("40-0064"));
		purchasePartList.add(partManagerTest.retrievePart("290B3810A1"));
		purchasePartList.add(partManagerTest.retrievePart("40-0063"));
		purchasePartList.add(partManagerTest.retrievePart("40-0059"));
		purchasePartList.add(partManagerTest.retrievePart("40-0058"));
		purchasePartList.add(partManagerTest.retrievePart("40-0011"));
		purchasePartList.add(partManagerTest.retrievePart("40-0055"));
		purchasePartList.add(partManagerTest.retrievePart("40-0054"));
		purchasePartList.add(partManagerTest.retrievePart("40-0057"));
		purchasePartList.add(partManagerTest.retrievePart("40-0056"));
		purchasePartList.add(partManagerTest.retrievePart("40-0051"));
		purchasePartList.add(partManagerTest.retrievePart("40-0050"));
		purchasePartList.add(partManagerTest.retrievePart("40-0053"));
		purchasePartList.add(partManagerTest.retrievePart("40-0052"));			
		List<Part> setList = partManagerTest.getPurchasePartsByPrice();
		assertEquals(purchasePartList, setList);
	}
	
	@Test
	public void verifyRetrieveInvalidPartNumberTest() {
		
		Part part = new Part();
		PartManager partManagerTest = new PartManagerImpl();
		partManagerTest.importPartStore("bom.json");
		part = partManagerTest.retrievePart("invalid part number");
		assertNull(part);
	}
	
	@Test
	public void verifyCostPartInvalidPartNumberTest() {
		
		Part part = new Part();
		PartManager partManagerTest = new PartManagerImpl();
		partManagerTest.importPartStore("bom.json");
		part = partManagerTest.costPart("invalid part number");
		assertNull(part);
	}
	
}
