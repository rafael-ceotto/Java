package edu.institution.asn11;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;

import org.junit.Test;

public class BSTtest {

	@Test
	public void GetHeightTreeTest() {
		BST<Integer> bst = new BST<Integer>();
		BST<Integer> bst2 = new BST<Integer>();
		BST<Integer> bst3 = new BST<Integer>();
		Integer[] unorderedList = { 1, 3, 2 };
		for (Integer number : unorderedList) {
			bst.insert(number);
			
		}
		bst3.insert(1000);
		assertEquals(bst.getHeight(bst.root), 3);
		assertEquals(bst2.getHeight(bst2.root), 0);
		assertEquals(bst3.getHeight(bst3.root), 1);
	}

	@Test
	public void TreeOrderTest() {
		BST<Integer> bst = new BST<Integer>();
		Integer[] unorderedList = { 1, 3, 2 };
		for (Integer number : unorderedList) {
			bst.insert(number);
		}
		ArrayList<TreeNode> listTOT  = new ArrayList<TreeNode>(bst.nonRecursiveInorder());
		Integer[] ordered = { 1, 2, 3 };
		assertEquals(listTOT.get(0).toString(), "1");
		assertEquals(listTOT.get(1).toString(), "2");
		assertEquals(listTOT.get(2).toString(), "3");
	}    

	@Test
	public void ReturningTreeWithBreadthFirstTest() {
		BST<Integer> binaryTree = new BST<Integer>();
		binaryTree.insert(100);
		binaryTree.insert(90);
		binaryTree.insert(226);
		binaryTree.insert(507);
		ArrayList<TreeNode> listBFT = new ArrayList<TreeNode>(binaryTree.breadthFirstTraversal());
		assertEquals(listBFT.get(0).element, 100);
		assertEquals(listBFT.get(1).element, 90);
		assertEquals(listBFT.get(2).element, 226);
		assertEquals(listBFT.get(3).element, 507);
				
	}
	
	@Test
	public void ReturningNullForBFT() {
		BST<Integer> binaryTree = new BST<Integer>();
		assertNull(binaryTree.breadthFirstTraversal());
	}
}
