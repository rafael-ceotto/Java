package edu.institution.asn9;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class SortAlgorithmMetricsTest {

	@Test
	public void showingRetrieveMethodTest() {
		SortAlgorithmMetrics sortTest = new SortAlgorithmMetrics();
		List<MetricData> sortList = sortTest.retrieveMetrics("asn9-numbers.txt");
		for (MetricData data : sortList) {
			System.out.println(data);
		}
	}

	@Test
	public void ifReturnSizeEqualsFiveAlgorithmics() {
		SortAlgorithmMetrics sortAlgorithm = new SortAlgorithmMetrics();
		assertEquals(sortAlgorithm.retrieveMetrics("asn9-numbers.txt").size(), 5);
	}

	@Test
	public void ifTheresnoRepetitions() {
		SortAlgorithmMetrics sortAlgorithm = new SortAlgorithmMetrics();
		List<MetricData> listMetric = sortAlgorithm.retrieveMetrics("asn9-numbers.txt");
		HashMap<String, Integer> countMap = new HashMap<String, Integer>();
		for (MetricData metric : listMetric) {
			if (countMap.get(metric.getSortAlgorithm().toString()) != null) {
				countMap.put(metric.getSortAlgorithm().toString(), countMap.get(metric.getSortAlgorithm().toString()) + 1);
			} else {
				countMap.put(metric.getSortAlgorithm().toString(), 1);
			}
		}
		Boolean hasDuplications = false;
		for(Map.Entry<String, Integer> entry : countMap.entrySet()) {
			if(entry.getValue() > 1) {
				hasDuplications = true;
			}
		}
		assertFalse(hasDuplications);
	}
	
	@Test
	public void ifIsCorrectlySortedAndHasTimeComplexity() {
		SortAlgorithmMetrics sortAlgorithm = new SortAlgorithmMetrics();
		List<MetricData> listMetric = sortAlgorithm.retrieveMetrics("asn9-numbers.txt");
		String[] algorithmsOrder = {"QUICK_SORT", "MERGE_SORT", "HEAP_SORT", "INSERTION_SORT", "BUBBLE_SORT"};
		List<String> retrieveOrder = new ArrayList<String>();
		for(MetricData metric: listMetric) {
			retrieveOrder.add(metric.getSortAlgorithm().toString());
			assertNotNull(metric.getTimeComplexity());
		}
		assertEquals(algorithmsOrder,retrieveOrder.toArray());
	}
}