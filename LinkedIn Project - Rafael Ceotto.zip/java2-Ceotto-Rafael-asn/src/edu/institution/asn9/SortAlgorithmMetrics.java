package edu.institution.asn9;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


public class SortAlgorithmMetrics {

	List<MetricData> metricDataList;

	public List<MetricData> retrieveMetrics(String filePath) {

		metricDataList = new ArrayList<MetricData>();
		File file = new File(filePath);
		if (file.exists()) {
		} else {
		}

		FileInputStream fis;
		try {
			fis = new FileInputStream(filePath);
			Scanner scan = new Scanner(fis);
			List<Integer> readingNumberList = new ArrayList<>();
			while (scan.hasNext()) {
				String readingLine = scan.nextLine();
				Integer readingNumber = Integer.parseInt(readingLine);
				readingNumberList.add(readingNumber);
			}
			scan.close();
			Collections.shuffle(readingNumberList);
			LocalTime start;
			LocalTime end;
			
			List<Integer> firstList = new ArrayList<Integer>(readingNumberList);
			List<Integer> secondList = new ArrayList<Integer>(readingNumberList);
			List<Integer> thirdList = new ArrayList<Integer>(readingNumberList);
			List<Integer> fourthList = new ArrayList<Integer>(readingNumberList);			
			List<Integer> fifthList = new ArrayList<Integer>(readingNumberList);

			/* Bubble sort */
			MetricData bubbleSortData = new MetricData(SortAlgorithm.BUBBLE_SORT);
			bubbleSortData.setTimeComplexity(TimeComplexity.QUADRATIC);
			Integer[] templateBubbleSort = {};
			start = LocalTime.now();
			BubbleSort.bubbleSort(firstList.toArray(templateBubbleSort));
			end = LocalTime.now();
			bubbleSortData.setExecutionTime(Duration.between(start, end).toMillis());
			this.metricDataList.add(bubbleSortData);

			/* Heap sort */
			MetricData heapSortData = new MetricData(SortAlgorithm.HEAP_SORT);
			heapSortData.setTimeComplexity(TimeComplexity.LOGARITHMIC);
			Integer[] templateHeapSort = {};
			start = LocalTime.now();
			HeapSort.heapSort(secondList.toArray(templateHeapSort));
			end = LocalTime.now();
			heapSortData.setExecutionTime(Duration.between(start, end).toMillis());
			this.metricDataList.add(heapSortData);
			
			/* Insertion sort */
			MetricData insertionSortData = new MetricData(SortAlgorithm.INSERTION_SORT);
			insertionSortData.setTimeComplexity(TimeComplexity.QUADRATIC);
			Integer[] templateInsertionSort = {};
			start = LocalTime.now();
			InsertionSort.insertionSort(thirdList.toArray(templateInsertionSort));
			end = LocalTime.now();
			insertionSortData.setExecutionTime(Duration.between(start, end).toMillis());
			this.metricDataList.add(insertionSortData);
			
			/* Quick sort */
			MetricData quickSortData = new MetricData(SortAlgorithm.QUICK_SORT);
			quickSortData.setTimeComplexity(TimeComplexity.QUADRATIC);
			Integer[] templateQuickSort = {};
			start = LocalTime.now();
			QuickSort.quickSort(fourthList.toArray(templateQuickSort));
			end = LocalTime.now();
			quickSortData.setExecutionTime(Duration.between(start, end).toMillis());
			this.metricDataList.add(quickSortData);
			
			/* Merge sort */
			MetricData mergeSortData = new MetricData(SortAlgorithm.MERGE_SORT);
			mergeSortData.setTimeComplexity(TimeComplexity.LOGARITHMIC);
			Integer[] templateMergeSort = {};
			start = LocalTime.now();
			MergeSort.mergeSort(fifthList.toArray(templateMergeSort));
			end = LocalTime.now();
			mergeSortData.setExecutionTime(Duration.between(start, end).toMillis());
			this.metricDataList.add(mergeSortData);
			
			Collections.sort(this.metricDataList);
			
			return new ArrayList<MetricData>(this.metricDataList);


		} catch (FileNotFoundException e) {
			return null;			
		}
	};
}