package edu.institution.midterm;

import java.io.Reader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;

public class PartManagerImpl implements PartManager{
	
	HashMap<String, Part> partMap;	
	
	public int importPartStore(String filePath) {		
		
		try {		    
		    Gson gson = new Gson();
		    Reader reader = Files.newBufferedReader(Paths.get(filePath));
			Part[] parts = gson.fromJson(reader, Part[].class);	
			this.partMap = new HashMap<String, Part>();
			for(Part part: parts) {
				this.partMap.put(part.getPartNumber(), part);
			}			
		    reader.close();				    
		} catch (Exception ex) {
		    ex.printStackTrace();
		}		
		return this.partMap.size();
	}
	
	public List<Part> getFinalAssemblies(){
		
		List<Part> assemblyPartsList = new ArrayList<Part>();
		for(Map.Entry<String, Part> entry : this.partMap.entrySet()) {
			if(Part.TYPE_ASSEMBLY.equals(entry.getValue().getPartType())) {
				assemblyPartsList.add(entry.getValue());
			}
		}
		Collections.sort(assemblyPartsList, new PartComparatorByPartNumber());
		return assemblyPartsList;
		
	}
	
	public List<Part> getPurchasePartsByPrice() {
		
		List<Part> purchasePartsList = new ArrayList<Part>();
		for(Map.Entry<String, Part> entry : this.partMap.entrySet()) {
			if(Part.TYPE_PURCHASE.equals(entry.getValue().getPartType())) {
				purchasePartsList.add(entry.getValue());
			}
		}
		Collections.sort(purchasePartsList, new PartComparatorByHigherPrice());
		return purchasePartsList;
	}
	
	public Part retrievePart(String partNumber) {
		 
		return this.partMap.get(partNumber);
	}
	
	public Part costPart(String partNumber) {
		
		Part part = retrievePart(partNumber);
		if(part == null) {
			return null;
		}		
		part.setPrice(summedPrice(part));
		return part;
	}
	
	private float summedPrice(Part part) {
		
		if(part.getBillOfMaterial() == null){
			return part.getPrice();			
		}
		List<BomEntry> bomEntries = part.getBillOfMaterial();
		float extendedPrice = 0.0f;
		for(BomEntry bomEntry : bomEntries) {
			Part bomEntryPart = this.retrievePart(bomEntry.getPartNumber());
			extendedPrice += roundForMoney(summedPrice(bomEntryPart) * bomEntry.getQuantity());
		}
		return roundForMoney(extendedPrice);
	}
	
	private float roundForMoney(float value) {
		
		return new BigDecimal(value).setScale(2, RoundingMode.HALF_UP).floatValue();
	}
			
}
