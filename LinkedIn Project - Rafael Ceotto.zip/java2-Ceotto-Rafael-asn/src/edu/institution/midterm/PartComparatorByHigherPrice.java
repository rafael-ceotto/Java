package edu.institution.midterm;

import java.util.Comparator;

public class PartComparatorByHigherPrice implements Comparator<Part>{

	@Override
	public int compare(Part o1, Part o2) {
		return (int) (o2.getPrice() - o1.getPrice());
	}

}
