/*
 Copyright (C) 2020. Doug Estep -- All Rights Reserved.
 Copyright Registration Number: TXU002159309.

 This file is part of the Tag My Code application.

 This application is protected under copyright laws and cannot be used, distributed, or copied without prior written
 consent from Doug Estep.  Unauthorized distribution or use is strictly prohibited and punishable by domestic and
 international law.

 Proprietary and confidential.
 */

package edu.institution;

import java.util.HashMap;
import java.util.List;
import edu.institution.asn2.LinkedInUser;


public class ApplicationHelper {

	//Explanation: Hashmap was chosen because it does not allows duplicates, since its index already do it.
	//Hashmap is also the fastest type of the maps and allows using a key values pair, so we can work with both instead of 
	//only one. Also, Hashmap does not care about the order, and since we're not looking for it, it fits well the assignment.
	
	private static HashMap<String, Integer> globalSkillSet = new HashMap<String, Integer>();
	
	public static void showMessage(String message) {
		System.out.println("\n" + message);
	}
	
	public static HashMap<String, Integer> getGlobalSkillSet(){
		return new HashMap<String, Integer>(ApplicationHelper.globalSkillSet);
	}
	
	public static void incrementSkillsetCount(String skillset) {
		if(ApplicationHelper.globalSkillSet.get(skillset) != null) {
			ApplicationHelper.globalSkillSet.put(skillset,ApplicationHelper.globalSkillSet.get(skillset) + 1);
		} else {
			ApplicationHelper.globalSkillSet.put(skillset, 1);
		}
	}	
	
	public static void decrementSkillsetCount(String skillset) {
		if(ApplicationHelper.globalSkillSet.get(skillset) != null) {
			ApplicationHelper.globalSkillSet.put(skillset,ApplicationHelper.globalSkillSet.get(skillset) - 1);
		} else {
			ApplicationHelper.globalSkillSet.put(skillset, 0);
		}	
	}	
	
	public static int retrieveSkillsetCount(String skillset){
		Integer count = ApplicationHelper.globalSkillSet.get(skillset);
		if(count != null) {
			return count;
		}
		return -1;		
	}	
	
	public static void initSkillsetUsages(List<LinkedInUser> users) {
						
		try {
			for(LinkedInUser user: users) {
				for(String skillSet: user.getSkillsets()) {
					ApplicationHelper.incrementSkillsetCount(skillSet);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
	  }

	}
}
