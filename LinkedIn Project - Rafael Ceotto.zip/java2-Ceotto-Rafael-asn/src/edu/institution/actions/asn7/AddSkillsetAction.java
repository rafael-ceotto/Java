package edu.institution.actions.asn7;

import java.util.Scanner;

import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.actions.asn10.UndoAction;
import edu.institution.asn2.LinkedInUser;

public class AddSkillsetAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {

		System.out.println("Type the Skillset you want to add: ");
		String skillSetName = scanner.nextLine();
		loggedInUser.getSkillsets().add(skillSetName);
		ApplicationHelper.incrementSkillsetCount(skillSetName);
		System.out.println(skillSetName + " has been added to your skillset");

		UndoAction.history.push("Add Skill|" + skillSetName);

		return true;
	}
}
