package edu.institution.actions.asn7;

import java.util.Scanner;

import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.actions.asn10.UndoAction;
import edu.institution.asn2.LinkedInUser;

public class RemoveSkillsetAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {

		System.out.println("Type the Skillset you want to remove: ");
		String skillSetName = scanner.nextLine();
		if (loggedInUser.getSkillsets().remove(skillSetName)) {
			ApplicationHelper.decrementSkillsetCount(skillSetName);
			System.out.println(skillSetName + " has been deleted from your skillset");
			UndoAction.history.push("Remove Skill|" + skillSetName);
		}

		return true;
	}
}
