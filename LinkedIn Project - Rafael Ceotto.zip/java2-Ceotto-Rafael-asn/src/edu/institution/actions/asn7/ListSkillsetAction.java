package edu.institution.actions.asn7;

import java.util.Scanner;

import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class ListSkillsetAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		if(loggedInUser.getSkillsets().size() == 0) {
			System.out.println("You have not entered any skillsets.");
			return true;
		}		
		for(String skillSet: loggedInUser.getSkillsets()) {
			Integer count = ApplicationHelper.getGlobalSkillSet().get(skillSet);
			System.out.println(skillSet + " (" + count + " users)" );			
		}		
		return true;
	}
}
