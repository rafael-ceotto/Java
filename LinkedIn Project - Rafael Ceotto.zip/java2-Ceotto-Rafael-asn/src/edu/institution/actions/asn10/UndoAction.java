package edu.institution.actions.asn10;

import java.util.Scanner;
import java.util.Stack;

import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class UndoAction implements MenuAction {

	public static Stack<String> history = new Stack<String>();

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {

		if(history.size() == 0) {
			System.out.println("No action left to undo. Please start one");
			return true;
		}
		String lastAction = history.pop();
		String[] actionData = lastAction.split("\\|");
		System.out.println("The last menu option selected was \"" + actionData[0] + "\" involving " + loggedInUser.getUsername()
				+ ". Undo (Y/N)?");
		String callAction = scanner.nextLine();
		if (callAction.equalsIgnoreCase("Y")) {
			try {
				if(actionData[0].equalsIgnoreCase("Add Connection")) {
					loggedInUser.removeConnection(userRepository.retrieve(actionData[1]));
					System.out.println("Removed " + actionData[1] + " from " + loggedInUser.getUsername() + " connections list");
				} else if(actionData[0].equalsIgnoreCase("Remove Connection")) {
					loggedInUser.addConnection(userRepository.retrieve(actionData[1]));
					System.out.println("Added " + actionData[1] + " to " + loggedInUser.getUsername() + " connections list");
				} else if(actionData[0].equalsIgnoreCase("Add skill")) {
					loggedInUser.removeSkillset(actionData[1]);
					System.out.println("Removed " + actionData[1] + " from " + loggedInUser.getUsername() + " skillset");
				} else if(actionData[0].equalsIgnoreCase("Remove skill")) {
					loggedInUser.addSkillset(actionData[1]);
					System.out.println("Add " + actionData[1] + " to " + loggedInUser.getUsername() + " skillset");
				}
			} catch (LinkedInException e) {
				e.printStackTrace();
			}
			
		} else if (callAction.equalsIgnoreCase("N")) {
			history.push(lastAction);
		}		
		
		return true;
	}

}
