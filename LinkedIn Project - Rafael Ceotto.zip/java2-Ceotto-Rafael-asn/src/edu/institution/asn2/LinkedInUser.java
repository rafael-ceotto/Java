//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021

package edu.institution.asn2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class LinkedInUser extends UserAccount implements Serializable, Comparable<LinkedInUser> {

	private static final long serialVersionUID = -3080292664859634039L;
	private String type;
	private List<LinkedInUser> connections = new ArrayList<>();
	private Set<String> skillsets = new TreeSet<String>();	
	
	public Set<String> getSkillsets(){
		return skillsets;
	}
	
	public void addSkillset(String skillset) {
		skillsets.add(skillset);
	}
	
	public void removeSkillset(String skillset) {
		skillsets.remove(skillset);

	}	

	public LinkedInUser(String username, String password) {
		super(username, password);
	}

	@Override
	public void setType(String type) {
		this.type = type;

	}

	public String getType() {
		return type;
	}

	public void addConnection(LinkedInUser user) throws LinkedInException {

		if (!connections.contains(user)) {
			connections.add(user);
		}else {
			throw new LinkedInException("You are already connected with this user");
		}

	}

	public void removeConnection(LinkedInUser user) throws LinkedInException {

		if (connections.contains(user)) {

			connections.remove(user);
			//user.removeConnection(this);

		}

		else {
			throw new LinkedInException("You are NOT connected with this user");
		}

	}

	public List<LinkedInUser> getConnections() {

		// copy of ArrayList
		return new ArrayList<LinkedInUser>(connections);
	}

	@Override
	public int compareTo(LinkedInUser linkUser) {
		return this.getUsername().compareToIgnoreCase(linkUser.getUsername());
	}

	@Override
	public String toString() {
		return this.getUsername();
	}
	
}
