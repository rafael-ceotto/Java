package edu.institution.finalproj;

import java.util.List;

public interface AnagramEvaluator {
	
	List<String> evaluate(String anagram, String option);
}
