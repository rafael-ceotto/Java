package edu.institution.finalproj;

import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

public class AnagrammerCLI {

	public static void main(String[] args) {

		CommandLineParser parserAnagramm = new DefaultParser();
		Options opt = new Options();
		opt.addOption("a", "anagram", true, "Supplies the anagram to evaluate");
		opt.addOption("h", "help", false, "Displays the help for this program");
		opt.addOption("nf", "no-filter", false, "Output all anagram values with no filter");
		opt.addOption("words", "filter-words", false, "Output only values that are known words");

		try {
			CommandLine cmd = parserAnagramm.parse(opt, args);

			if (cmd.hasOption("h") || cmd.hasOption("--help")) {
				System.out.println("usage: anagrammer");
				System.out.println("Options");
				System.out.println("-a,--anagram <word>     Supplies the anagram to evaluate");
				System.out.println("-h,--help               Displays this help textdisplays the help for thisprogram");
				System.out.println("-nf,--no-filter         Output all anagram values with no filter");
				System.out.println("-words,--filter-words   Output only values that are known words");
			}
			if (cmd.hasOption("a") || cmd.hasOption("--anagram")) {
				AnagramEvaluatorImpl readingWords = new AnagramEvaluatorImpl();
				String anagram = cmd.getOptionValue("a");

				if (cmd.hasOption("nf") || cmd.hasOption("--no-filter")) {
					List<String> words = readingWords.evaluate(anagram, "nf");
					System.out.println("Anagrammer -nf -a " + anagram );
					for (String wordsItem : words) {
						System.out.println(wordsItem);
					}
					System.out.println("-- " + words.size() + " value(s) are found");
				}
				if (cmd.hasOption("words") || cmd.hasOption("--filter-words")) {
					AnagramEvaluatorImpl readingRealWords = new AnagramEvaluatorImpl();
					String anagramWords = cmd.getOptionValue("a");
					if (cmd.hasOption("words")) {
						System.out.println("Anagrammer -a " + anagramWords + " -words");
						List<String> realWords = readingRealWords.evaluate(anagramWords, "words");
						for (String wordsRealItem : realWords) {
							System.out.println(wordsRealItem);
						}
						System.out.println("-- " + realWords.size() + " value(s) are found");
					}
				}

			}

		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

}
