package edu.institution.finalproj;

import java.io.FileInputStream;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class AnagramDataReaderImpl implements AnagramDataReader {

	@Override
	public Set<String> readData() {
		// File readingFile = new File("anagram_data.txt");
		Scanner scanFile;
		Set<String> setWords = new HashSet<String>();
		FileInputStream fis;
		try {
			fis = new FileInputStream("anagram_data.txt");
			scanFile = new Scanner(fis);
			while (scanFile.hasNextLine()) {
				String getFileData = scanFile.nextLine();
				setWords.add(getFileData);
			}
			scanFile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return setWords;
	}
}
