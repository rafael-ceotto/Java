package edu.institution.finalproj;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class AnagramEvaluatorImpl implements AnagramEvaluator {

	List<String> anagrams = new ArrayList<String>();
	List<String> uniqueAnagrams = new ArrayList<String>();
	List<String> evaluatedWords = new ArrayList<String>();
	Set<String> dataWords;

	@Override
	public List<String> evaluate(String anagram, String option) {

		AnagramDataReader wordsReader = new AnagramDataReaderImpl();
		this.dataWords = wordsReader.readData();

		this.anagram(anagram, 0, anagram.length() - 1);

		if (option.equals("nf")) {
			return this.getUniqueAnagrams();
		} else {
			return this.getEvaluatedWords();
		}
	}

	/**
	 * https://www.codespeedy.com/how-to-generate-anagrams-in-java/
	 */
	
	/*By this part, the anagram method works by checking the the word is inside the list of unique anagrams. If it's not there,
	 *then we should add to the list. If it's there and matches a word known by the list after the swap of characters, then we
	 *should add the word and display by using the evaluated Words. For the Swap method we're using holders to store the value
	 *and then change with the next value, which means that we will be substituting one value by the other.
	 */
	private void anagram(String str, int start, int end) {
		if (start == end) {
			if (!uniqueAnagrams.contains(str)) {
				uniqueAnagrams.add(str);

				if (this.dataWords.contains(str.toUpperCase())) {
					evaluatedWords.add(str);
				}
			}

			anagrams.add(str);
		} else {
			for (int i = start; i <= end; i++) {
				str = swap(str, start, i);
				anagram(str, start + 1, end);
				str = swap(str, start, i);
			}
		}
	}

	public String swap(String a, int i, int j) {
		char temp;
		char[] charArray = a.toCharArray();
		temp = charArray[i];
		charArray[i] = charArray[j];
		charArray[j] = temp;
		return String.valueOf(charArray);
	}

	public List<String> getAnagrams() {
		return anagrams;
	}

	public List<String> getUniqueAnagrams() {
		return uniqueAnagrams;
	}

	public List<String> getEvaluatedWords() {
		return evaluatedWords;				
	}
}