package edu.institution.asn11;

public class BSTimplementation {

	public static void main(String[] args) {
		
		String[] list = {"2", "3", "4", "5", "1", "10", "9",};
		BST<String> bst = new BST<String>();
		for(String name: list) {
			bst.insert(name);
		}		
	}	
}
